@extends('template.master')
@section('contenido-principal')
<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Rut</th>
      <th scope="col">Fecha</th>
      <th scope="col">Documento</th>
      <th scope="col">Estado</th>
      <th scope="col">Comentario</th>
    </tr>
  </thead>
  <tbody>
    @foreach($estudiante->propuesta as $index=>$propuesta)
    <tr>
      <td>{{$propuesta->id}}</td>
      <td>{{$propuesta->estudiante_rut}}</td>
      <td>{{$propuesta->fecha}}</td>
      <td>{{$propuesta->documento}}</td>
      <td>
        <select class="form-select" aria-label="Default select example" disabled>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='0') selected @endif>Esperado Revision</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='1') selected @endif>Aprobado</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='2') selected @endif>Rechazado</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='3') selected @endif>Modificar Propuesta</option>
        </select>
      </td>

      <td>
        <a href="{{route('estudiante.comentario',$propuesta->id)}}" class="btn btn-secondary">Ver comentarios</a>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>
@endsection