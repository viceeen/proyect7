
<?php $__env->startSection('contenido-principal'); ?>
<br>
<div class="row">
  <div class="col-4">
    <div class="card" style="width: 30rem;">
      <div class="card-header">
        <img class="card-img-top" src="<?php echo e(asset('images/profesor.png')); ?>" alt="" >
      </div>
      <div class="card-body">
        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#profesor">
          Agregar Profesor
        </button>

        <!-- Modal -->
        <div class="modal fade" id="profesor" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form method="POST" action="<?php echo e(route('profesor.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="profesor_rut" class="form-label">Rut</label>
                            <input name="profesor_rut"type="text" id="profesor_rut" class="form-control">
                        </div>
                        <div class="mb-3">                                                
                            <label for="profesor_nombre" class= "form-label">Nombre</label>
                            <input name="profesor_nombre" type="text" id="profesor_nombre" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="profesor_apellido" class="form-label">Apellido</label>
                            <input name="profesor_apellido" type="text" id="profesor_apellido" class="form-control">
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                          <button type="submit" class="btn btn-primary">Agregar</button>
                        </div>
                  </form>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-4">
    <div class="card" style="width: 30rem;">
      <div class="card-header">
        <img class="card-img-top" src="<?php echo e(asset('images/alumno.png')); ?>" alt="" >
      </div>
      <div class="card-body">
        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#estudiante">
          Agregar Estudiante
        </button>

          <!-- Modal -->
          <div class="modal fade" id="estudiante" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel1">Modal title</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form method="POST" action="<?php echo e(route('estudiantes.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">                                                
                            <label for="nombre" class= "form-label">Nombre</label>
                            <input name="nombre" type="text" id="nombre" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="apellido" class="form-label">Apellido</label>
                            <input name="apellido" type="text" id="apellido" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="rut" class="form-label">Rut</label>
                            <input name="rut"type="text" id="rut" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input name="email" type="email" id="email" class="form-control">
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                          <button type="submit" class="btn btn-primary">Agregar</button>
                        </div>
                  </form>
                </div>
                
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>

  <div class="col-4">
    <div class="card" style="width: 30rem;">
      <div class="card-header">
        <img class="card-img-top" src="<?php echo e(asset('images/documento.jpg')); ?>" alt="" >
      </div>
      <div class="card-body">

      </div>
    </div>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/home.blade.php ENDPATH**/ ?>