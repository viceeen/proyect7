
<?php $__env->startSection('hojas-estilo'); ?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido-principal'); ?>
<br>
<div class=row>
    <div class="col">
        <div class="card">
            <div class="card-header">
                <div class="row d-flex justify-content-between">
                    <div class="col">
                        <h4>Estudiantes</h4>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Rut</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Ver Propuestas</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($estudiante->rut); ?></th>
                        <td><?php echo e($estudiante->nombre); ?></td>
                        <td><?php echo e($estudiante->apellido); ?></td>
                        <td>
                          <a href="<?php echo e(route('profesor.estudiante',$estudiante->rut)); ?>" class="btn btn-secondary">
                            <span class="material-icons">visibility</span>
                          </a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/profesor/index.blade.php ENDPATH**/ ?>