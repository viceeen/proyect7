
<?php $__env->startSection('contenido-principal'); ?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Rut</th>
      <th scope="col">Fecha</th>
      <th scope="col">Documento</th>
      <th scope="col">Estado</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $propuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($propuesta->id); ?></th>
      <td><?php echo e($propuesta->estudiante_rut); ?></td>
      <td><?php echo e($propuesta->fecha); ?></td>
      <td>
        <a href="   " class="btn btn-secondary"></a>
      </td>
      <td>
        <select class="form-select" aria-label="Default select example" disabled>
          <option value="<?php echo e($propuesta->estado); ?>"<?php if($propuesta->estado=='0'): ?> selected <?php endif; ?>>Esperado Revision</option>
          <option value="<?php echo e($propuesta->estado); ?>"<?php if($propuesta->estado=='1'): ?> selected <?php endif; ?>>Aprobado</option>
          <option value="<?php echo e($propuesta->estado); ?>"<?php if($propuesta->estado=='2'): ?> selected <?php endif; ?>>Rechazado</option>
          <option value="<?php echo e($propuesta->estado); ?>"<?php if($propuesta->estado=='3'): ?> selected <?php endif; ?>>Modificar Propuesta</option>
        </select>
      </td>
      <td>  
        <a href="<?php echo e(route('propuesta.edit',$propuesta->id)); ?>" class="btn btn-secondary">Editar</a>       
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/propuestas.blade.php ENDPATH**/ ?>