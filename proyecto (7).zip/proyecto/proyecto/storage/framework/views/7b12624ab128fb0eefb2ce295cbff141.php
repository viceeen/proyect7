
<?php $__env->startSection('contenido-principal'); ?>
<div class="row">
    <div class="col">
        <table class="table">
            <thead>
                <tr>
                <th scope="col">ID</th>
                <th scope="col">Rut Profesor</th>
                <th scope="col">Fecha</th>
                <th scope="col">Hora</th>
                <th scope="col">Comentario</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $profesor_propuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor_propuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($profesor_propuesta->propuesta_id); ?></th>
                        <td><?php echo e($profesor_propuesta->profesor_rut); ?></td>
                        <td><?php echo e($profesor_propuesta->fecha); ?></td>
                        <td><?php echo e($profesor_propuesta->hora); ?></td>
                        <td><?php echo e($profesor_propuesta->comentario); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('comentario.destroy', $propuesta->id)); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-secondary">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/profesor/comentarios.blade.php ENDPATH**/ ?>